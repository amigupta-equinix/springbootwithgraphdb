package com.test.graphdb.service;

import java.util.List;

import com.test.graphdb.dto.PersonDTO;

/**
 * @author amitkumar_gupta
 *
 */
public interface PersonService {
	
	/**
	 * createPerson
	 * @param dto
	 * @return
	 */
	public PersonDTO createdPerson(PersonDTO dto);
	
	
	/**
	 * updatePerson
	 * @param dto
	 * @return
	 */
	public PersonDTO updatePerson(PersonDTO dto);

	

	/**
	 * markDElete
	 * @param id
	 * @return
	 */
	public PersonDTO markDelete(Long id); 
	
	
	/**
	 * connectPerson
	 * @param name1
	 * @param name2
	 * @return
	 */
	public PersonDTO connectPerson(String name1, String name2); 
	
}
