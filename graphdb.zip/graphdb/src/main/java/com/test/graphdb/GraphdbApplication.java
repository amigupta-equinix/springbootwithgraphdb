package com.test.graphdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author amitkumar_gupta
 *
 */
@SpringBootApplication
public class GraphdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphdbApplication.class, args);
	}

}
