package com.test.graphdb.configs;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger.web.InMemorySwaggerResourcesProvider;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;


/**
 * @author amitkumar_gupta
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
	
	@Bean
    public Docket productApi() {
        
        ApiInfo apiInfo = new ApiInfoBuilder().title("Graph Db Test")
            .description("Crud Opration with Spring Boot and Graph DB Neo4J")
            .contact(new Contact("Amit Kumar Gupta", "", "amitguptaedu053@gmail.com"))
            .version("0.1").build();
        
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo);
    }
    
    public static class CombinedSwaggerResources implements SwaggerResourcesProvider {
        @Resource
        private InMemorySwaggerResourcesProvider inMemorySwaggerResourcesProvider;

        @Override
        public List<SwaggerResource> get() {
            SwaggerResource jaxRsResource = new SwaggerResource();
            jaxRsResource.setLocation("/json/swagger.json");
            jaxRsResource.setSwaggerVersion("2.0");
            jaxRsResource.setName("Application-Documentation");
            return Stream.concat(Stream.of(jaxRsResource), inMemorySwaggerResourcesProvider.get().stream()).collect(Collectors.toList());
        }

    }
	

}
