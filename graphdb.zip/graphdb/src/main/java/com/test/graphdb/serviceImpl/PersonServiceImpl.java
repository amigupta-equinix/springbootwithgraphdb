package com.test.graphdb.serviceImpl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.test.graphdb.dto.PersonDTO;
import com.test.graphdb.entity.Person;
import com.test.graphdb.repository.PersonRepository;
import com.test.graphdb.service.PersonService;

/**
 * @author  amitkumar_gupta
 *
 */
@Service
public class PersonServiceImpl implements PersonService{
	
	@Autowired
	private PersonRepository personRepository;

	@Override
	public PersonDTO createdPerson(PersonDTO dto) {
		Person existingPerson =personRepository.findByfullName(dto.getFullName());
		if (existingPerson != null) {
			throw new RuntimeException("Person already exists!");
		}
		Person person=convertDTOToEntity(dto);
		person= personRepository.save(person);
		return converEntityToDTO(person);
	}

	@Override
	public PersonDTO updatePerson(PersonDTO dto) {
		Optional<Person> existingPerson =personRepository.findById(dto.getId());
		if(existingPerson==null) {
			throw new RuntimeException("Person does not exists!");
		}
	   existingPerson.ifPresent(e->{
		   e.setFullName(dto.getFullName());
		   e.setEmail(dto.getEmail());
		   e.setModifiedDate(dto.getModifiedDate());
		   e.setPhoneNo(dto.getPhoneNo());
		   e.setCreatedDate(dto.getCreatedDate());
		   personRepository.save(e);
	   });
		return dto;
	}

	@Override
	public PersonDTO markDelete(Long id) {
		Optional<Person> existingPerson =personRepository.findById(id);
		if(existingPerson==null) {
			throw new RuntimeException("Person does not exists!");
		}
		PersonDTO Persondto=new PersonDTO();
	     existingPerson.ifPresent(e->{
		   Persondto.setId(e.getId());
		   Persondto.setFullName(e.getFullName());
		   Persondto.setEmail(e.getEmail());
		   personRepository.delete(e);
	     });
		return Persondto;
	}

	@Override
	public PersonDTO connectPerson(String name1, String name2) {
		Person person1 =personRepository.findByfullName(name1);
		Person person2 =personRepository.findByfullName(name2);
		person1.worksWith(person2);
		person1=personRepository.save(person1);
		return converEntityToDTO(person1);
	}
	
	private PersonDTO converEntityToDTO(Person person) {
		PersonDTO personDTO=new PersonDTO();
		if(person!=null) {
			personDTO.setId(person.getId());
			personDTO.setFullName(person.getFullName());
			personDTO.setEmail(person.getEmail());
			personDTO.setCreatedDate(person.getCreatedDate());
			personDTO.setModifiedDate(person.getModifiedDate());
			if(!person.getTeammates().isEmpty()) {
				Set<PersonDTO> teammates=new HashSet<>();
				for(Person p:person.getTeammates()) {
					PersonDTO dto=new PersonDTO();
					dto.setId(p.getId());
					dto.setFullName(p.getFullName());
					dto.setEmail(p.getEmail());
					dto.setCreatedDate(p.getCreatedDate());
					dto.setModifiedDate(p.getModifiedDate());
					teammates.add(dto);
				}
				personDTO.setTeammates(teammates);
			}
		}
		return personDTO;
		
	}
 
	private Person convertDTOToEntity(PersonDTO dto) {
		Person person=new Person();
		if(dto!=null) {
			if(dto.getId()!=null)
				dto.setId(person.getId());
				dto.setFullName(person.getFullName());
				dto.setEmail(person.getEmail());
				dto.setCreatedDate(person.getCreatedDate());
				dto.setModifiedDate(person.getModifiedDate());
		}
		return person;
		
	}
}
