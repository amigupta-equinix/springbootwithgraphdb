package com.test.graphdb.constant;

/**
 * @author amitkumar_gupta
 *
 */
public class SwaggerConstants {

	private SwaggerConstants() {}

	/**
	 * Status 200
	 */
	public static final int S200 = 200;
	
	/**
	 * Status 200 Message
	 */
	public static final String S200_MESSAGE = "Successfully saved";


	/**
	 * Status 400
	 */
	public static final int S400 = 400;
	
	/**
	 * Status 400 Message
	 */
	public static final String S400_MESSAGE = "Bad Request";

	/**
	 * Status 401
	 */
	public static final int S401 = 401;
	
	/**
	 * Status 401 Message
	 */
	public static final String S401_MESSAGE = "You are not authorized to view the resource";

	/**
	 * Status 403
	 */
	public static final int S403 = 403;
	
	/**
	 * Status 403 Message
	 */
	public static final String S403_MESSAGE = "Accessing the resource you were trying to reach is forbidden";

	/**
	 * Status 404
	 */
	public static final int S404 = 404;
	
	/**
	 * Status 404 Message
	 */
	public static final String S404_MESSAGE = "The resource you were trying to reach is not found";

	/**
	 * Status 409
	 */
	public static final int S409 = 409;
	
	/**
	 * Status 409 Message
	 */
	public static final String S409_MESSAGE = "Access Denied";

	/**
	 * Status 500
	 */
	public static final int S500 = 500;
	
	/**
	 * Status 500 Message
	 */
	public static final String S500_MESSAGE = "Exception Generated";

}
