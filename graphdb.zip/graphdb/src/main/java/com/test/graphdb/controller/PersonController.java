package com.test.graphdb.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.test.graphdb.constant.SwaggerConstants;
import com.test.graphdb.dto.PersonDTO;
import com.test.graphdb.service.PersonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.annotations.Tag;

/**
 * @author amitkumar_gupta
 *
 */
@RestController
@RequestMapping("/person")
@Api(tags = {"Person Management System"})
@SwaggerDefinition(tags = { @Tag(name = "Person Management System", description = "This API has been provided the crud operation with neo4j databse") })
public class PersonController {
	private final static Logger log = LoggerFactory.getLogger(PersonController.class.getName());
	
	@Autowired
	private PersonService personService;
	
	
	@PostMapping("/createPerson")
	@ApiOperation(value = "Create new Person end point", response = PersonDTO.class)
	@ApiResponses(value = {
		    @ApiResponse(code = SwaggerConstants.S200, message = SwaggerConstants.S200_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S401, message = SwaggerConstants.S401_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S403, message = SwaggerConstants.S403_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S404, message = SwaggerConstants.S404_MESSAGE)
		})
	public ResponseEntity<PersonDTO> createPerson(@ApiParam(value = "Create new person", required = true) @Valid @RequestBody PersonDTO dto) {
		log.info("Create API called");
		return new ResponseEntity<>(personService.createdPerson(dto), HttpStatus.OK);
	}
	
	@PatchMapping("/updatePerson")
	@ApiOperation(value = "Update New Person end point", response = PersonDTO.class)
	@ApiResponses(value = {
		    @ApiResponse(code = SwaggerConstants.S200, message = SwaggerConstants.S200_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S401, message = SwaggerConstants.S401_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S403, message = SwaggerConstants.S403_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S404, message = SwaggerConstants.S404_MESSAGE)
		})
	public ResponseEntity<PersonDTO> updatePerson(@ApiParam(value = "Update existing person ", required = true) @RequestBody @Valid PersonDTO dto){
		log.info("Update API called");
		return new ResponseEntity<>(personService.updatePerson(dto), HttpStatus.OK);
	}
	

	@DeleteMapping("/deletePerson")
	@ApiOperation(value = "Delete perrson end point", response =  PersonDTO.class)
	@ApiResponses(value = {
		    @ApiResponse(code = SwaggerConstants.S200, message = SwaggerConstants.S200_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S401, message = SwaggerConstants.S401_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S403, message = SwaggerConstants.S403_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S404, message = SwaggerConstants.S404_MESSAGE)
		})
	public ResponseEntity<PersonDTO> deletePerson(@ApiParam(value = "Id", required = true)@RequestParam("id")Long id) {
		log.info("delete person by id");
		return new ResponseEntity<>(personService.markDelete(id), HttpStatus.OK);
	}

	
	@GetMapping("/connectPersons")
	@ApiOperation(value = "Connect persons end point", response =  PersonDTO.class)
	@ApiResponses(value = {
		    @ApiResponse(code = SwaggerConstants.S200, message = SwaggerConstants.S200_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S401, message = SwaggerConstants.S401_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S403, message = SwaggerConstants.S403_MESSAGE),
		    @ApiResponse(code = SwaggerConstants.S404, message = SwaggerConstants.S404_MESSAGE)
		})
	public ResponseEntity<PersonDTO> connetPerson(@ApiParam(value = "First Persone Name", required = true)@RequestParam("fullName1")String fullname1,@ApiParam(value = "Second Person Name", required = true)@RequestParam("fullName2")String fullName2) {
		log.info("Connect Two person");
		return new ResponseEntity<>(personService.connectPerson(fullname1, fullName2), HttpStatus.OK);
	}
	
}
