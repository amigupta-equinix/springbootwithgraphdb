package com.test.graphdb.repository;

import org.springframework.data.repository.CrudRepository;

import com.test.graphdb.entity.Person;

/**
 * @author amitkumar_gupta
 *
 */
public interface PersonRepository extends CrudRepository<Person, Long>{
	Person findByfullName(String name);
	
}

